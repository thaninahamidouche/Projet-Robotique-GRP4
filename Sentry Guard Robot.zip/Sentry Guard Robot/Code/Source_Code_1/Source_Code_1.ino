#include <Servo.h> 
#define SentryDelay_ms 15 // use longer delay for slower sweep 
#define ServoPWM 9 
#define ObstaclePIN 2 
#define LaserPIN 3 
#define BuzzerPIN 4 
Servo myservo;  
int sentryPos = 0, sentryMove = 1; 
 
void setup() { 
  // put your setup code here, to run once:  
  Serial.begin(9600); 
  pinMode(ObstaclePIN, INPUT); 
  pinMode(LaserPIN, OUTPUT); 
  pinMode(BuzzerPIN, OUTPUT); 
  myservo.attach(ServoPWM);  // attaches the servo on pin 9 to the servo 
 
  myservo.write(0); 
} 
 
void loop() { 
  // put your main code here, to run repeatedly: 
 
  sentryPos += sentryMove;  
  if (sentryPos >= 180) 
    sentryMove = -1; 
 
  if (sentryPos <= 0) 
    sentryMove = +1; 
 
  myservo.write(sentryPos); 
  delay(SentryDelay_ms); 
 
  while(digitalRead(ObstaclePIN) == LOW) 
  { 
    Serial.println("Intruder Detected!"); 
    delay(100); 
    digitalWrite(LaserPIN, HIGH); 
    digitalWrite(BuzzerPIN, HIGH); 
    delay(100); 
    digitalWrite(LaserPIN, LOW); 
    digitalWrite(BuzzerPIN, LOW); 
  }    
} 
