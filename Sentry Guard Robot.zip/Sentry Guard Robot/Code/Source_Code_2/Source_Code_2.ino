#include <Servo.h> 
#include <LiquidCrystal_I2C.h>

#define SentryDelay_ms 15 // use longer delay for slower sweep 
#define ServoPWM 9 
#define ObstaclePIN 2 
#define LaserPIN 3 
#define BuzzerPIN 4

LiquidCrystal_I2C lcd(0x27, 16, 2); 
Servo myservo;  
int sentryPos = 0, sentryMove = 1; 
char LCD_Buff[16];
 
void setup() { 
// put your setup code here, to run once:  
Serial.begin(9600); 
pinMode(ObstaclePIN, INPUT); 
 pinMode(LaserPIN, OUTPUT); 
  pinMode(BuzzerPIN, OUTPUT); 
  myservo.attach(ServoPWM);  // attaches the servo on pin 9 to the servo 
  myservo.write(0); 
  lcd.init(); // initialize LCD 
  lcd.clear();  // clear the current display 
  lcd.backlight();  // turn on the backlight 
  lcd.setCursor(0, 0);  // set the cursor to the start of the display 
  lcd.print("Scanning ..."); 
} 
 
void loop() { 
  // put your main code here, to run repeatedly: 
 
  sentryPos += sentryMove;  
  if (sentryPos >= 180) 
    sentryMove = -1; 
 
  if (sentryPos <= 0) 
    sentryMove = +1; 
 
  myservo.write(sentryPos); 
  delay(SentryDelay_ms); 
 
  while(digitalRead(ObstaclePIN) == LOW) 
  { 
    Serial.println("Intruder Detected!"); 
    lcd.setCursor(0, 0);  // set the cursor to the start of the display 
    lcd.print("INTRUDER DTD"); 
    sprintf(LCD_Buff, "@%dDEG", (int)(180-sentryPos)); 
    lcd.setCursor(0, 1);  // set the cursor to the start of the display 
    lcd.print(LCD_Buff); 
    delay(100); 
    digitalWrite(LaserPIN, HIGH); 
    digitalWrite(BuzzerPIN, HIGH); 
    delay(100); 
    digitalWrite(LaserPIN, LOW); 
    digitalWrite(BuzzerPIN, LOW); 
    lcd.clear(); 
    lcd.setCursor(0, 0);  // set the cursor to the start of the display 
    lcd.print("Scanning ..."); 
  }   
   
}